import sys
from PyQt5.QtWidgets import (
        QApplication, QWidget, QLabel, QPushButton, QSpinBox, QFrame
    )
from PyQt5.QtCore import pyqtSlot, QRect

class MainPage(QWidget):
    def __init__(self, title=" "):
        super().__init__()  # inherit init of QWidget
        self.title = title
        self.left = 250
        self.top = 250
        self.width = 400
        self.height = 300
        self.widget()

    def widget(self):
        # window setup
        self.setWindowTitle(self.title)
        # self.setGeometry(self.left, self.top, self.width, self.height)
        ## use above line or below
        self.resize(self.width, self.height)
        self.move(self.left, self.top)

        # create frame for a set of checkbox
        self.frame1 = QFrame(self)
        self.frame1.setGeometry(QRect(40, 40, 250, 80))
        # create spin box
        self.spinbox1 = QSpinBox(self.frame1)
        self.spinbox1.setValue(3) # default value
        self.spinbox1.setMinimum(0) # minimum value
        self.spinbox1.setMaximum(6) # maximum value
        self.spinbox1.move(0, 50)
        self.spinbox1.valueChanged.connect(self.spinbox1_changed)
        # spinbox value will be displayed on label
        self.label1 = QLabel(self.frame1, text="Value in spin box is " + str(self.spinbox1.value()))
        self.label1.setGeometry(QRect(0, 20, 500, 20))


        self.show()

    @pyqtSlot()
    def spinbox1_changed(self):
        self.label1.setText("Value in spin box is "+str(self.spinbox1.value()))


def main():
    app = QApplication(sys.argv)
    w = MainPage(title="PyQt5")
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()